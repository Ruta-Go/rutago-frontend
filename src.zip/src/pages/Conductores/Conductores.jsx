import { useState, useEffect } from "react";
import { usePaginacion } from "../../hooks/usePaginacion";
import Pagination from "../../components/Pagination/Pagination";
import Modal from "../../components/Modal/Modal";
import ActionsMenu from "../../components/ActionsMenu/ActionsMenu";
import TableToolbar from "../../components/TableToolbar/TableToolbar";
import { conductorService } from "../../services/conductor.service";
import { usuariosService } from "../../services/usuarios.service";
import PasswordInput from "../../components/PasswordInput/PasswordInput";
import { useEstadosConductor } from "../../hooks/useEstadosConductor";
import "./Conductores.css";

const emptyForm = {
  nombres: "",
  apellidos: "",
  correo: "",
  contrasena: "",
  usuarioId: "",
  licenciaConducir: "",
  estadoId: 1,
};

export default function Conductores() {
  const { opciones: opcionesEstadosConductor, nombre: nombreEstadoConductor } = useEstadosConductor();
  const [conductores, setConductores] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingConductor, setEditingConductor] = useState(null);
  const [formData, setFormData] = useState(emptyForm);

  const {
    currentPage,
    itemsPerPage,
    pagination,
    handlePageChange,
    handleItemsPerPageChange,
    actualizarPaginacion,
    queryParams,
  } = usePaginacion();

  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({ estadoId: "" });
  const [sortBy, setSortBy] = useState("id");
  const [sortOrder, setSortOrder] = useState("ASC");

  const fetchDatos = async () => {
    try {
      setLoading(true);
      const [conductoresData, usuariosData] = await Promise.all([
        conductorService.getAll({
          ...queryParams,
          q: searchTerm || undefined,
          ...(filters.estadoId && { estadoId: filters.estadoId }),
          sortBy,
          sortOrder,
        }),
        usuariosService.getAll({
          paginaActual: 1,
          registrosPorPagina: 100,
        }),
      ]);

      setConductores(conductoresData.data || []);
      actualizarPaginacion(conductoresData.paginacion);
      setUsuarios(usuariosData.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDatos();
  }, [queryParams, searchTerm, filters, sortBy, sortOrder]);

  const handleNuevo = () => {
    setEditingConductor(null);
    setFormData(emptyForm);
    setError("");
    setModalOpen(true);
  };

  const handleEditar = (conductor) => {
    setEditingConductor(conductor);
    setFormData({
      nombres: conductor.usuario?.nombres || "",
      apellidos: conductor.usuario?.apellidos || "",
      correo: conductor.usuario?.correo || "",
      usuarioId: conductor.usuario?.id,
      licenciaConducir: conductor.licenciaConducir || "",
      estadoId: conductor.estado?.id || 1,
    });
    setError("");
    setModalOpen(true);
  };

  const handleGuardar = async () => {
    try {
      if (editingConductor) {
        const usuarioIdEdicion = editingConductor.usuario?.id ?? null;

        // Solo actualizar el usuario si existe la asociación
        if (usuarioIdEdicion) {
          await usuariosService.update(usuarioIdEdicion, {
            nombres: formData.nombres,
            apellidos: formData.apellidos,
            correo: formData.correo,
          });
        }

        await conductorService.update(editingConductor.id, {
          licenciaConducir: formData.licenciaConducir,
          estadoId: formData.estadoId,
        });
      } else {
        await conductorService.crearConUsuario({
          nombres: formData.nombres,
          apellidos: formData.apellidos,
          correo: formData.correo,
          contrasena: formData.contrasena,
          licenciaConducir: formData.licenciaConducir,
          estadoId: formData.estadoId,
        });
      }
      await fetchDatos();
      setModalOpen(false);
      setEditingConductor(null);
      setFormData(emptyForm);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleCerrarModal = () => {
    setModalOpen(false);
    setEditingConductor(null);
    setFormData(emptyForm);
    setError("");
  };

  const handleEliminar = async (id) => {
    if (
      !window.confirm("¿Estás seguro de que deseas eliminar este conductor?")
    ) {
      return;
    }

    try {
      await conductorService.delete(id);
      await fetchDatos();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleSearchChange = (value) => {
    setSearchTerm(value);
  };

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const sortOptions = [
    { value: "id", label: "ID" },
    { value: "licenciaConducir", label: "Licencia" },
    { value: "estado", label: "Estado" },
  ];

  const handleSortChange = (field, order) => {
    setSortBy(field);
    setSortOrder(order);
  };

  const getUsuarioNombre = (conductor) => {
    if (conductor.usuario) {
      return `${conductor.usuario.nombres} ${conductor.usuario.apellidos || ""}`.trim();
    }

    const usuario = usuarios.find((u) => u.id === conductor.usuario?.id);
    return usuario
      ? `${usuario.nombres} ${usuario.apellidos || ""}`.trim()
      : "Sin usuario";
  };

  const getEstadoColor = (estadoId) => {
    const colors = {
      1: "badge-disponible",
      2: "badge-en-viaje",
      3: "badge-inactivo",
    };
    return colors[estadoId] || "badge-default";
  };

  const conductoresPaginados = conductores;

  return (
    <div className="conductores-container">
      <div className="page-header">
        <h1>Gestión de Conductores</h1>
      </div>
      {error && !modalOpen && <p className="error">{error}</p>}

      <div className="table-container">
        <div className="table-actions" style={{ marginBottom: "1rem" }}>
          <button onClick={handleNuevo} className="button button-primary">
            + Nuevo Conductor
          </button>
        </div>

        <TableToolbar
          searchValue={searchTerm}
          onSearchChange={handleSearchChange}
          placeholder="Buscar por nombres, apellidos, correo o licencia..."
          filters={[
            {
              name: "estadoId",
              label: "Todos los estados",
              value: filters.estadoId,
              options: opcionesEstadosConductor(),
            },
          ]}
          onFilterChange={handleFilterChange}
          sortOptions={sortOptions}
          sortBy={sortBy}
          sortOrder={sortOrder}
          onSortChange={handleSortChange}
        />
        <div className="bg-white rounded-lg shadow-sm">
          {loading ? (
            <div className="loading-container">
              <div className="spinner"></div>
              <p>Cargando conductores...</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="desktop-table">
                <table className="table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Usuario</th>
                      <th>Licencia</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {conductoresPaginados.length > 0 ? (
                      conductoresPaginados.map((conductor) => (
                        <tr key={conductor.id}>
                          <td>{conductor.id}</td>
                          <td>
                            <span className="font-medium">
                              {getUsuarioNombre(conductor)}
                            </span>
                          </td>
                          <td>{conductor.licenciaConducir || "-"}</td>
                          <td>
                            <span
                              className={`badge ${getEstadoColor(conductor.estado?.id)}`}
                            >
                              {nombreEstadoConductor(conductor.estado?.id) ||
                                conductor.estado?.nombre ||
                                conductor.estado?.id}
                            </span>
                          </td>
                          <td>
                            <ActionsMenu
                              onEdit={() => handleEditar(conductor)}
                              onDelete={() => handleEliminar(conductor.id)}
                            />
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="5" className="text-center">
                          No se encontraron conductores
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="mobile-cards">
                {conductoresPaginados.length > 0 ? (
                  <div className="mobile-cards-list">
                    {conductoresPaginados.map((conductor) => (
                      <div key={conductor.id} className="mobile-card">
                        <div className="mobile-card-header">
                          <div className="mobile-card-info">
                            <h3>{getUsuarioNombre(conductor)}</h3>
                            <p>Licencia: {conductor.licenciaConducir || "-"}</p>
                          </div>
                          <span
                            className={`mobile-badge ${getEstadoColor(conductor.estado?.id)}`}
                          >
                            {(
                              nombreEstadoConductor(conductor.estado?.id) ||
                              conductor.estado?.nombre ||
                              conductor.estado?.id ||
                              ""
                            )
                              .toString()
                              .toUpperCase()}
                          </span>
                        </div>

                        <div className="mobile-card-body">
                          <div className="mobile-card-row">
                            <span>ID</span>
                            <span>{conductor.id}</span>
                          </div>
                        </div>

                        <div className="mobile-card-actions">
                          <ActionsMenu
                            onEdit={() => handleEditar(conductor)}
                            onDelete={() => handleEliminar(conductor.id)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="mobile-empty">
                    No hay conductores disponibles
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {!loading && (
          <Pagination
            currentPage={currentPage}
            totalPages={pagination?.totalPaginas || 1}
            totalItems={pagination?.totalRegistros || conductores.length}
            itemsPerPage={itemsPerPage}
            onPageChange={handlePageChange}
            onItemsPerPageChange={handleItemsPerPageChange}
          />
        )}
      </div>

      <Modal
        isOpen={modalOpen}
        onClose={handleCerrarModal}
        title={editingConductor ? "Editar Conductor" : "Nuevo Conductor"}
      >
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleGuardar();
          }}
        >
          {!editingConductor ? (
            <>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Nombres
                </label>
                <input
                  type="text"
                  value={formData.nombres}
                  onChange={(e) =>
                    setFormData({ ...formData, nombres: e.target.value })
                  }
                  className="input"
                  style={{ width: "100%" }}
                  required
                />
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Apellidos
                </label>
                <input
                  type="text"
                  value={formData.apellidos}
                  onChange={(e) =>
                    setFormData({ ...formData, apellidos: e.target.value })
                  }
                  className="input"
                  style={{ width: "100%" }}
                  required
                />
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Correo
                </label>
                <input
                  type="email"
                  value={formData.correo}
                  onChange={(e) =>
                    setFormData({ ...formData, correo: e.target.value })
                  }
                  className="input"
                  style={{ width: "100%" }}
                  required
                />
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Contraseña
                </label>
                <PasswordInput
                  value={formData.contrasena}
                  onChange={(e) =>
                    setFormData({ ...formData, contrasena: e.target.value })
                  }
                  placeholder="Contraseña"
                  required
                />
              </div>
            </>
          ) : (
            <>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Nombres
                </label>
                <input
                  type="text"
                  value={formData.nombres}
                  onChange={(e) =>
                    setFormData({ ...formData, nombres: e.target.value })
                  }
                  className="input"
                  style={{ width: "100%" }}
                  required
                />
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Apellidos
                </label>
                <input
                  type="text"
                  value={formData.apellidos}
                  onChange={(e) =>
                    setFormData({ ...formData, apellidos: e.target.value })
                  }
                  className="input"
                  style={{ width: "100%" }}
                />
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "0.5rem",
                    fontWeight: "500",
                  }}
                >
                  Correo
                </label>
                <input
                  type="email"
                  value={formData.correo}
                  onChange={(e) =>
                    setFormData({ ...formData, correo: e.target.value })
                  }
                  className="input"
                  style={{ width: "100%" }}
                  required
                />
              </div>
            </>
          )}
          <div style={{ marginBottom: "1rem" }}>
            <label
              style={{
                display: "block",
                marginBottom: "0.5rem",
                fontWeight: "500",
              }}
            >
              Licencia
            </label>
            <input
              type="text"
              value={formData.licenciaConducir}
              onChange={(e) =>
                setFormData({ ...formData, licenciaConducir: e.target.value })
              }
              className="input"
              style={{ width: "100%" }}
            />
          </div>
          <div style={{ marginBottom: "1.5rem" }}>
            <label
              style={{
                display: "block",
                marginBottom: "0.5rem",
                fontWeight: "500",
              }}
            >
              Estado
            </label>
            <select
              value={formData.estadoId}
              onChange={(e) =>
                setFormData({ ...formData, estadoId: parseInt(e.target.value) })
              }
              className="input"
              style={{ width: "100%" }}
              required
            >
              {opcionesEstadosConductor().map((op) => (
                <option key={op.value} value={op.value}>
                  {op.label}
                </option>
              ))}
            </select>
          </div>
          {error && <p className="error">{error}</p>}
          <div
            style={{
              display: "flex",
              gap: "0.5rem",
              justifyContent: "flex-end",
            }}
          >
            <button
              type="button"
              onClick={handleCerrarModal}
              className="button button-outline"
            >
              Cancelar
            </button>
            <button type="submit" className="button button-primary">
              Guardar
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
